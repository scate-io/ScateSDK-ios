//
//  ScateSDK.h
//  ScateSDK
//

#import <Foundation/Foundation.h>

//! Project version number for ScateSDK.
FOUNDATION_EXPORT double ScateSDKVersionNumber;

//! Project version string for ScateSDK.
FOUNDATION_EXPORT const unsigned char ScateSDKVersionString[];


// In this header, you should import all the public headers of your framework using statements like #import <ScateSDK/PublicHeader.h>

@class ScateCoreSDK;
